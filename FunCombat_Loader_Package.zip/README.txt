Fun Combat Loader Package

Contents:
- loader.lua: the loader script supplied in the conversation.

Important:
This ZIP contains the loader only. It does not contain the external GUI modules or assets.
The loader expects these files to exist in the GitHub repository:
- manifest.json
- config/assets.json
- config/identifiers.json
- config/protocol.json
- client/<module-name>.lua for each module declared in manifest.json

This loader uses executor-specific APIs such as loadstring/getgenv and is not a standard
Roblox Studio LocalScript. Do not run unknown executor scripts unless you trust and have
reviewed all source files. For a normal Roblox Studio project, the modules should be
converted into standard LocalScripts/ModuleScripts and server scripts as needed.
